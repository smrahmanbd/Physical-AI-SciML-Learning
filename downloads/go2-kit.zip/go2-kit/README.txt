Physical AI and SciML in three goes: Go 2 lab kit

Install: pip install -r requirements.txt
Run any lab: python <file>.py
Each script prints the numbers quoted on its module page. All data are synthetic teaching data.
Files ending in _torch.py need PyTorch (pip install torch); the others need only NumPy.
